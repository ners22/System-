<?php
require_once 'config.php'; // Database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Dashboard</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" />
  <style>
    body {
      background: url("imahe/mama.jpg") no-repeat center center fixed;
      background-size: cover;
      color: #ffffff;
      font-family: Arial, sans-serif;
    }

    .overlay {
      background-color: rgba(0, 0, 0, 0.85);
      min-height: 100vh;
      padding-bottom: 40px;
    }

    .navbar {
      background-color: #111;
      padding: 15px;
    }

    .navbar-brand {
      font-weight: bold;
      color: #ffa31a !important;
      font-size: 24px;
    }

    .dashboard {
      margin-top: 50px;
    }

    .card {
      background-color: #1c1c1c;
      border: none;
      color: #dddddd;
      transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
    }

    .card .card-title,
    .card .card-text {
      color: #dddddd;
    }

    .card:hover {
      transform: scale(1.05);
      box-shadow: 0px 0px 15px rgba(255, 163, 26, 0.5);
    }

    .btn-orange {
      background-color: #ffa31a;
      color: #0f0f0f;
      font-weight: bold;
    }

    .btn-orange:hover {
      background-color: #ff8c00;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="overlay">
    <nav class="navbar navbar-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="#">Admin</a>
      </div>
    </nav>

    <div class="container dashboard">
      <div class="row">
        
        <!-- Manage Users -->
        <div class="col-md-3 mb-4">
          <div class="card text-light p-3">
            <div class="card-body text-center">
              <h5 class="card-title">👤 Manage Users</h5>
              <p class="card-text">View and manage registered users.</p>
              <a href="manage_users.php" class="btn btn-orange">Go to Users</a>
            </div>
          </div>
        </div>

        <!-- Manage Food Items -->
        <div class="col-md-3 mb-4">
          <div class="card text-light p-3">
            <div class="card-body text-center">
              <h5 class="card-title">🍔 Manage Food Items</h5>
              <p class="card-text">Add, edit, or remove food items.</p>
              <a href="manage_food.php" class="btn btn-orange">Go to Food</a>
            </div>
          </div>
        </div>

        <!-- Manage Riders -->
        <div class="col-md-3 mb-4">
          <div class="card text-light p-3">
            <div class="card-body text-center">
              <h5 class="card-title">🚴‍♂️ Manage Riders</h5>
              <p class="card-text">Add or update delivery rider info.</p>
              <a href="manage_riders.php" class="btn btn-orange">Go to Riders</a>
            </div>
          </div>
        </div>

        <!-- Confirm Orders -->
        <div class="col-md-3 mb-4">
          <div class="card text-light p-3">
            <div class="card-body text-center">
              <h5 class="card-title">📦 Confirm Orders</h5>
              <p class="card-text">Review and confirm pending orders.</p>
              <a href="confirm_orders.php" class="btn btn-orange">Go to Orders</a>
            </div>
          </div>
        </div>

        <!-- Applications -->
        <div class="col-md-3 mb-4">
          <div class="card text-light p-3">
            <div class="card-body text-center">
              <h5 class="card-title">📝 Job Applications</h5>
              <p class="card-text">View applicants and resumes.</p>
              <a href="applicants.php" class="btn btn-orange">View Applications</a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
