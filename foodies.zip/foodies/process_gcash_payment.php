<?php
session_start();
include('config.php'); // Optional if you want to save transaction to DB

// Example: You can log transaction here (optional)
/*
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $total_price = 0;
    foreach ($_SESSION['cart'] as $item) {
        $total_price += $item['price'] * $item['quantity'];
    }
    
    $stmt = $conn->prepare("INSERT INTO orders (payment_method, total_amount, status) VALUES (?, ?, ?)");
    $payment_method = "GCASH";
    $status = "PAID";
    $stmt->bind_param("sds", $payment_method, $total_price, $status);
    $stmt->execute();
}
*/

// Clear Cart
unset($_SESSION['cart']);

// Redirect to Thank You Page
header("Location: thank_you.php?method=gcash");
exit;
?>
