<?php
session_start();
// Retrieve cart items from session to show confirmation details
$cart_items = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total_price = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Success</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
            text-align: center;
        }
        .success-container {
            background-color: #1a1a1a;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(255, 102, 0, 0.3);
            padding: 30px;
            max-width: 600px;
            width: 100%;
            box-sizing: border-box;
        }
        .success-container h2 {
            color: #ff8800;
            font-weight: 600;
            margin-bottom: 20px;
        }
        .success-container p {
            font-size: 16px;
            color: #ddd;
        }
        .order-summary {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #444;
        }
        .order-summary h3 {
            color: #ff8800;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            color: #ddd;
            margin-bottom: 15px;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #444;
        }
        th {
            color: #ff8800;
        }
        .total {
            font-size: 18px;
            font-weight: bold;
            color: #ff8800;
            margin-top: 20px;
        }
        button {
            margin-top: 30px;
            padding: 12px;
            background-color: #ff8800;
            color: #fff;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background-color: #ff6600;
        }
    </style>
</head>
<body>
<div class="success-container">
    <h2>Order Successful!</h2>
    <p>Thank you for your order! Your order has been successfully placed. We will process it shortly.</p>
    <div class="order-summary">
        <h3>Order Summary</h3>
        <table>
            <thead>
                <tr>
                    <th>Item</th>
                    <th>Qty</th>
                    <th>Price</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($cart_items)): ?>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']) ?></td>
                            <td><?= $item['quantity'] ?></td>
                            <td>₱<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                        </tr>
                        <?php $total_price += $item['price'] * $item['quantity']; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <div class="total">Total: ₱<?= number_format($total_price, 2) ?></div>
    </div>
    <button onclick="window.location.href='index.php'">Return to Homepage</button>
</div>
</body>
</html>
