<?php
session_start();
include('config.php');

$appetizers_sql = "SELECT * FROM menu WHERE category = 'Appetizer'";
$main_sql = "SELECT * FROM menu WHERE category = 'Main Course'";
$desserts_sql = "SELECT * FROM menu WHERE category = 'Dessert'";

$appetizers_result = $conn->query($appetizers_sql);
$main_result = $conn->query($main_sql);
$desserts_result = $conn->query($desserts_sql);

$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Foodies - Menu</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Playfair+Display:wght@500&family=Poppins:wght@400;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        display: flex;
        flex-direction: column;
        align-items: center;
    }
    .menu-container {
        width: 90%;
        max-width: 1200px;
        background: rgba(0, 0, 0, 0.9);
        padding: 30px;
        margin-top: 50px;
        border-radius: 12px;
        box-shadow: 0 0 25px rgba(255, 153, 0, 0.6);
    }
    .cart-btn {
        position: absolute;
        top: 20px;
        right: 20px;
        background: #ffd700;
        color: black;
        font-weight: bold;
        padding: 10px 15px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        box-shadow: 0 0 10px #ffd700;
    }
    .cart-count {
        background: red;
        color: white;
        font-size: 14px;
        font-weight: bold;
        border-radius: 50%;
        padding: 5px 8px;
        position: absolute;
        top: -5px;
        right: -5px;
        font-family: 'Playfair Display', serif;
    }
    .filter-btns {
        text-align: center;
        margin-bottom: 20px;
    }
    .filter-btns button {
        background: #ff9800;
        color: black;
        font-weight: bold;
        padding: 8px 15px;
        margin: 5px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
        transition: 0.3s;
    }
    .filter-btns button:hover {
        background: #ffc107;
    }
    .category-section {
        margin-bottom: 30px;
    }
    .category-title {
        text-align: center;
        font-size: 30px;
        margin: 20px 0 15px;
        color: #ffd700;
        font-family: 'Dancing Script', cursive;
        text-shadow: 1px 1px 5px black;
    }
    .menu-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
    }
    .category-item {
        background: #111;
        border-radius: 10px;
        overflow: hidden;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 15px;
        text-align: center;
        transition: transform 0.2s, box-shadow 0.2s;
        box-shadow: 0 0 10px rgba(255, 255, 255, 0.1);
    }
    .category-item:hover {
        transform: scale(1.05);
        box-shadow: 0 0 15px #ff9800;
    }
    .category-item img {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 5px;
        margin-bottom: 10px;
    }
    .item-name {
        font-size: 20px;
        font-weight: bold;
        color: #fff;
        margin-bottom: 5px;
    }
    .item-desc {
        font-size: 14px;
        color: #cccccc;
        margin-bottom: 10px;
    }
    .item-price {
        font-family: 'Playfair Display', serif;
        font-weight: bold;
        color: #ffcc80;
        font-size: 20px;
    }
    .overlay, .popup {
        display: none;
        position: fixed;
        z-index: 1000;
    }
    .overlay {
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
    }
    .popup {
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        background: #1a1a1a;
        padding: 20px;
        border-radius: 10px;
        width: 320px;
        text-align: center;
        color: white;
        box-shadow: 0 0 15px #00ffcc;
    }
    .popup img {
        width: 100%;
        border-radius: 10px;
        margin-bottom: 10px;
    }
    .close-btn {
        position: absolute;
        top: 10px;
        right: 15px;
        cursor: pointer;
        font-size: 18px;
        color: #00ffcc;
    }
    .add-to-cart {
        background: #00ffcc;
        color: black;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-weight: bold;
        transition: background 0.3s;
    }
    .add-to-cart:hover {
        background: #1affd5;
    }
</style>
</head>
<body>

<button onclick="window.location.href='index.php'" style="position: absolute; top: 20px; left: 20px; background: #ff9800; color: black; font-weight: bold; padding: 10px 15px; border-radius: 5px; border: none; cursor: pointer;">
⬅ Back to Home
</button>

<button class="cart-btn" onclick="window.location.href='cart.php'">
🛒 Cart <span class="cart-count" id="cart-count"><?php echo $cart_count; ?></span>
</button>

<div class="menu-container">
<h1 style="text-align: center; color:#ff9800;">Job & Grab's Menu</h1>

<div class="filter-btns">
    <button onclick="filterCategory('all')">All</button>
    <button onclick="filterCategory('appetizer')">Appetizers</button>
    <button onclick="filterCategory('main')">Main Courses</button>
    <button onclick="filterCategory('dessert')">Desserts</button>
</div>

<div id="appetizer-section" class="category-section">
    <h2 class="category-title">Appetizers</h2>
    <div class="menu-grid">
    <?php while ($item = $appetizers_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

<div id="main-section" class="category-section">
    <h2 class="category-title">Main Courses</h2>
    <div class="menu-grid">
    <?php while ($item = $main_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

<div id="dessert-section" class="category-section">
    <h2 class="category-title">Desserts</h2>
    <div class="menu-grid">
    <?php while ($item = $desserts_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

</div>

<div id="overlay" class="overlay"></div>
<div id="popup" class="popup">
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <img id="popup-image" src="" alt="Food Image">
    <h2 id="popup-name"></h2>
    <p id="popup-description"></p>
    <h3 id="popup-price"></h3>
    
    <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin: 15px 0;">
        <button onclick="adjustQuantity(-1)" style="background: #ff9800; color: black; font-weight: bold; padding: 5px 10px; border-radius: 5px; border: none; cursor: pointer;">-</button>
        
        <input type="number" id="quantity" min="1" value="1" style="width: 80px; text-align: center; background: #222; color: white; border: 1px solid #ff9800; border-radius: 4px; padding: 5px;">
        
        <button onclick="adjustQuantity(1)" style="background: #ff9800; color: black; font-weight: bold; padding: 5px 10px; border-radius: 5px; border: none; cursor: pointer;">+</button>
    </div>

    <button class="add-to-cart" onclick="addToCart()">Add to Cart</button>
</div>

<script>
let selectedItem = {};

function showPopup(id, name, description, price, image) {
    selectedItem = { id, name, price };
    document.getElementById("popup-name").innerText = name;
    document.getElementById("popup-description").innerText = description;
    document.getElementById("popup-price").innerText = '₱' + parseFloat(price).toFixed(2);
    document.getElementById("popup-image").src = image;
    document.getElementById("quantity").value = 1;
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}

function adjustQuantity(change) {
    const qtyInput = document.getElementById("quantity");
    let quantity = parseInt(qtyInput.value) || 1;
    quantity += change;
    if (quantity < 1) quantity = 1;
    qtyInput.value = quantity;
}

function addToCart() {
    const quantity = document.getElementById("quantity").value;
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "add_to_cart.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("cart-count").innerText = xhr.responseText;
            alert("Added to cart!");
            closePopup();
        }
    };

    xhr.send(`id=${selectedItem.id}&name=${encodeURIComponent(selectedItem.name)}&price=${selectedItem.price}&quantity=${quantity}`);
}

function filterCategory(category) {
    document.getElementById('appetizer-section').style.display = (category === 'all' || category === 'appetizer') ? 'block' : 'none';
    document.getElementById('main-section').style.display = (category === 'all' || category === 'main') ? 'block' : 'none';
    document.getElementById('dessert-section').style.display = (category === 'all' || category === 'dessert') ? 'block' : 'none';
}
</script>

</body>
</html>
