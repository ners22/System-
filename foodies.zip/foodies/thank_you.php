<?php
$method = isset($_GET['method']) ? $_GET['method'] : 'Unknown Payment Method';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
    <style>
        body {
            background: url("imahe/mama.jpg") no-repeat center center fixed;
            background-size: cover;
            font-family: 'Poppins', sans-serif;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            text-align: center;
        }
        .thank-you-container {
            background: rgba(0, 0, 0, 0.85);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(255, 153, 0, 0.5);
            max-width: 400px;
            width: 90%;
        }
        h1 {
            color: #ff9900;
            margin-bottom: 15px;
        }
        p {
            font-size: 18px;
            margin-bottom: 20px;
        }
        button {
            padding: 12px 20px;
            background: #ff9900;
            color: black;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: 0.3s;
        }
        button:hover {
            background: #e68000;
        }
    </style>
</head>
<body>

<div class="thank-you-container">
    <h1>Thank You!</h1>
    <p>Your order has been placed successfully.</p>
    <p>Payment Method: <strong><?= htmlspecialchars(ucfirst($method)) ?></strong></p>
    <button onclick="window.location.href='menu.php'">Back to Menu</button>
</div>

</body>
</html>
