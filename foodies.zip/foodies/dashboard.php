<?php
session_start();
include('config.php'); // Include database connection

// Check if the user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Fetch food items from the database
$sql = "SELECT * FROM foods";  // Assuming you have a 'foods' table
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Food Ordering</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Nunito', sans-serif; background-color: #f8f9fa; color: #333; padding-top: 80px; }
        
        .container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background: white;
            box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
            border-radius: 8px;
            text-align: center;
        }

        h2 { margin-bottom: 20px; }
        
        .food-list {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            justify-content: center;
        }

        .food-item {
            width: 45%;
            background: #fff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0px 2px 6px rgba(0,0,0,0.1);
            text-align: center;
        }

        .food-item img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 6px;
        }

        .food-item h3 { font-size: 18px; margin-top: 10px; }

        .food-item p { font-size: 14px; color: #555; }

        .logout {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #d9534f;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: 0.3s;
        }

        .logout:hover { background: #c9302c; }

        @media (max-width: 768px) {
            .food-item { width: 100%; }
        }
    </style>
</head>
<body>

<?php include('header.php'); ?>  <!-- Include the header -->

<div class="container">
    <h2>Welcome, <?php echo htmlspecialchars($username); ?>! 🍔</h2>
    <h3>Available Foods</h3>

    <div class="food-list">
        <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="food-item">
                        <img src="' . htmlspecialchars($row['image_url']) . '" alt="Food Image">
                        <h3>' . htmlspecialchars($row['name']) . '</h3>
                        <p>' . htmlspecialchars($row['description']) . '</p>
                        <p><strong>Price:</strong> $' . htmlspecialchars($row['price']) . '</p>
                      </div>';
            }
        } else {
            echo '<p>No foods available.</p>';
        }
        ?>
    </div>
    
    <a href="logout.php" class="logout">Logout</a>
</div>

</body>
</html>
