<?php
// Start session
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job & Grab - Home</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    html, body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        background-attachment: fixed;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    .container {
        flex: 1;
        padding: 20px;
    }
    .welcome-message {
        text-align: center;
        margin-top: 50px;
        padding: 20px;
        border-radius: 10px;
        width: 80%;
        max-width: 600px;
        margin-left: auto;
        margin-right: auto;
        background: rgba(0, 0, 0, 0.5);
    }
    .welcome-message h2 {
        font-size: 30px;
        font-weight: bold;
        color: #FFA500;
        text-shadow: 2px 2px 5px black;
    }
    .welcome-message p {
        font-size: 18px;
        color: #fff;
        font-weight: 500;
        margin-top: 15px;
    }
    .slideshow-container {
        position: relative;
        max-width: 500px;
        height: 250px;
        margin: 30px auto;
        overflow: hidden;
        border-radius: 10px;
        box-shadow: 0px 4px 10px rgba(0,0,0,0.2);
    }
    .slide { display: none; width: 100%; height: 100%; }
    .slide img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 10px;
    }
    .fade { animation: fadeEffect 1.5s ease-in-out; }
    @keyframes fadeEffect {
        from { opacity: 0.4; }
        to { opacity: 1; }
    }
    .menu {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        margin-top: 30px;
        gap: 20px;
    }
    .menu div {
        background: linear-gradient(135deg, #ff9933, #ffcc66);
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        text-align: center;
        width: 220px;
        color: #fff;
        transition: transform 0.3s ease;
    }
    .menu div:hover { transform: scale(1.05); }
    .menu div h3 {
        margin-bottom: 15px;
        font-size: 20px;
        font-weight: 700;
        color: #fff;
    }
    .menu div a {
        color: #fff;
        background: rgba(0,0,0,0.2);
        padding: 8px 15px;
        border-radius: 5px;
        text-decoration: none;
        display: inline-block;
        margin-top: 10px;
        font-weight: bold;
    }
    .menu div a:hover {
        background: rgba(0,0,0,0.4);
    }
    footer {
        background: black;
        color: white;
        padding: 20px;
        text-align: center;
        margin-top: auto;
    }
</style>
</head>

<body>

<?php include 'header.php'; ?>

<div class="container">
    <div class="welcome-message">
        <?php if (isset($_SESSION['username'])): ?>
            <h2>Welcome back, <?php echo htmlspecialchars($_SESSION['username']); ?>! 👋</h2>
            <p>Your cravings are calling — grab your favorites now and satisfy that hunger!</p>
        <?php else: ?>
            <h2>Welcome to <span style="color: #FFD700;">Job & Grab</span>! </h2>
            <p>Discover mouthwatering dishes, explore irresistible flavors, and grab your next meal with ease!</p>
        <?php endif; ?>
    </div>

    <div class="slideshow-container">
        <div class="slide fade"><img src="images/appetizer.jpg" alt="Delicious Appetizers"></div>
        <div class="slide fade"><img src="images/mainC.jpg" alt="Tasty Main Courses"></div>
        <div class="slide fade"><img src="images/sweet.jpg" alt="Sweet Desserts"></div>
    </div>

    <div class="menu">
        <div>
            <h3>View Applications</h3>
            <a href="applicants.php">Check Applicants</a>
        </div>
    </div>
</div>

<footer>
    <p>&copy; 2025 Job & Grab. All rights reserved.</p>
</footer>

<script>
    let slideIndex = 0;
    function showSlides() {
        let slides = document.getElementsByClassName("slide");
        for (let i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) { slideIndex = 1; }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 3000);
    }
    showSlides();
</script>

</body>
</html>
