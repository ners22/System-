<?php
require_once 'config.php'; // Database connection

// Add new rider
if (isset($_POST['add_rider'])) {
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $zone = $_POST['zone'];
    mysqli_query($conn, "INSERT INTO riders (name, contact, zone) VALUES ('$name', '$contact', '$zone')");
    header("Location: manage_riders.php");
    exit();
}

// Delete rider
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM riders WHERE id='$id'");
    header("Location: manage_riders.php");
    exit();
}

// Edit mode
$edit_mode = false;
$edit_id = "";
$edit_name = "";
$edit_contact = "";
$edit_zone = "";

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = $_GET['edit'];
    $res = mysqli_query($conn, "SELECT * FROM riders WHERE id='$edit_id'");
    if ($row = mysqli_fetch_assoc($res)) {
        $edit_name = $row['name'];
        $edit_contact = $row['contact'];
        $edit_zone = $row['zone'];
    }
}

// Update rider
if (isset($_POST['update_rider'])) {
    $id = $_POST['rider_id'];
    $name = $_POST['name'];
    $contact = $_POST['contact'];
    $zone = $_POST['zone'];
    mysqli_query($conn, "UPDATE riders SET name='$name', contact='$contact', zone='$zone' WHERE id='$id'");
    header("Location: manage_riders.php");
    exit();
}

// Fetch all riders
$riders = mysqli_query($conn, "SELECT * FROM riders");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Riders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #0f0f0f; color: #fff; }
        .navbar { background-color: #111; }
        .navbar-brand { color: #ffa31a !important; font-weight: bold; }
        .container { margin-top: 40px; background-color: #1a1a1a; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(255, 163, 26, 0.5); }
        .form-control { background-color: #333; color: #fff; border: 1px solid #ffa31a; }
        .form-control::placeholder { color: #bbb; }
        .btn-orange { background-color: #ffa31a; color: #0f0f0f; font-weight: bold; border: none; }
        .btn-orange:hover { background-color: #ff8c00; color: #fff; }
        .btn-back { background-color: #333; color: #ffa31a; border: 1px solid #ffa31a; }
        .btn-back:hover { background-color: #ffa31a; color: #000; }
        .btn-danger { background-color: #ff4d4d; border: none; }
        .btn-danger:hover { background-color: #cc0000; }
        th { background-color: #222; color: #ffa31a; }
        tr:hover { background-color: #292929; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container-fluid d-flex justify-content-between">
        <a class="navbar-brand" href="#">Manage Riders</a>
    </div>
</nav>

<div class="container">
    <h2 class="text-center mb-4"><?= $edit_mode ? '✏️ Edit Rider' : '🚴‍♂️ Add New Rider' ?></h2>

    <form method="POST" class="mb-4">
        <input type="hidden" name="rider_id" value="<?= $edit_id ?>">
        <div class="mb-3">
            <input type="text" name="name" class="form-control" placeholder="Rider Name" value="<?= $edit_name ?>" required>
        </div>
        <div class="mb-3">
            <input type="text" name="contact" class="form-control" placeholder="Contact Number" value="<?= $edit_contact ?>" required>
        </div>
        <div class="mb-3">
            <input type="text" name="zone" class="form-control" placeholder="Delivery Zone" value="<?= $edit_zone ?>" required>
        </div>
        <button type="submit" name="<?= $edit_mode ? 'update_rider' : 'add_rider' ?>" class="btn btn-orange w-100">
            <?= $edit_mode ? '💾 Update Rider' : '➕ Add Rider' ?>
        </button>
    </form>

    <table class="table table-dark table-hover text-center">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Contact</th>
                <th>Zone</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($rider = mysqli_fetch_assoc($riders)): ?>
                <tr>
                    <td><?= $rider['id'] ?></td>
                    <td><?= htmlspecialchars($rider['name']) ?></td>
                    <td><?= htmlspecialchars($rider['contact']) ?></td>
                    <td><?= htmlspecialchars($rider['zone']) ?></td>
                    <td>
                        <a href="manage_riders.php?edit=<?= $rider['id'] ?>" class="btn btn-orange btn-sm">✏️ Edit</a>
                        <a href="manage_riders.php?delete=<?= $rider['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this rider?')">❌ Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- ✅ Back to Admin Button -->
    <a href="admin.php" class="btn btn-back w-100 mt-3">⬅️ Back to Admin</a>
</div>

</body>
</html>
