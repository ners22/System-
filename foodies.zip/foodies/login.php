<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Job & Grab Login </title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Roboto', sans-serif;
            background: url("uploads/bgfood.png") no-repeat center center fixed;
            background-size: cover;
            background-attachment:fixed;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
        }

        body::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0 ,0.5);
            backdrop-filter: blur(5px);
        }
        .login-container {
            background: rgba(0, 0, 0, 1);
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 0 15px rgba(255, 102, 0, 0.5);
            z-index: 1;
        }
        h1 {
            font-size: 28px;
            color: white;
            margin-bottom: 25px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.7);
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        label {
            font-size: 16px;
            color: #ff9900;
            font-weight: bold;
            letter-spacing: 0.5px;
            display: block;
            margin-bottom: 5px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.7);
        }
        input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #444;
            background: #222;
            color: white;
            margin-top: 5px;
            box-shadow: inset 0 0 5px rgba(255, 153, 0, 0.2);
            transition: 0.3s;
        }
        input:focus {
            outline: none;
            box-shadow: 0 0 8px rgba(255, 153, 0, 0.7);
        }
        button {
            width: 100%;
            padding: 12px;
            background: #ff9900;
            border: none;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            color: black;
            transition: 0.3s;
            margin-top: 10px;
        }
        button:hover {
            background: #cc7700;
        }
        .signup-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .signup-link a {
            color: #ff9900;
            text-decoration: none;
            font-weight: bold;
        }
        .signup-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Job & Grab Login</h1>
        <form action="index.php" method="POST">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
        <div class="signup-link">
            <p>Don't have an account? <a href="signup.php">Sign Up Here</a></p>
        </div>
    </div>
</body>
</html>
