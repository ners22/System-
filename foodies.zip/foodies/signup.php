<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - FoodieHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Roboto', sans-serif;
            background: url("uploads/stir-fry-recipe.jpg") no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
        }
        .signup-container {
            background: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0px 5px 15px rgba(255, 152, 0, 0.3);
            text-align: center;
            animation: slideDown 0.6s ease-out;
        }
        h1 {
            font-size: 28px;
            font-weight: 600;
            color: #ff9800;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative;
            text-align: left;
        }
        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
            color: #bbb;
        }
        input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: none;
            background: #333;
            color: white;
            transition: 0.3s;
        }
        input:focus {
            outline: none;
            background: #444;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #ff9800;
            border: none;
            color: black;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #ffb74d;
        }
        .login-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .login-link a {
            color: #ff9800;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h1>Sign Up</h1>
        <form action="login.php" method="POST">
            <div class="form-group">
                <label for="name">Username</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" name="address" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            <p>Already have an account? <a href="login.php">Login Here</a></p>
        </div>
    </div>
</body>
</html>
