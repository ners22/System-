<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job & Grab - Application Form</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Pacifico&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        color: #fff;
        margin: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    header {
        background: rgba(0, 0, 0, 0.8);
        padding: 20px;
        text-align: center;
        font-size: 28px;
        color: #ff8800;
        font-family: 'Pacifico', cursive;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        position: relative;
    }
    .back-btn {
        position: absolute;
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
        background: linear-gradient(135deg, #ff8800, #ff6600);
        color: white;
        padding: 8px 15px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        text-decoration: none;
        box-shadow: 0 0 10px rgba(255, 136, 0, 0.5);
        transition: background 0.3s, transform 0.3s;
    }
    .back-btn:hover {
        background: linear-gradient(135deg, #ff6600, #cc5200);
        transform: translateY(-50%) scale(1.05);
    }
    .container {
        max-width: 600px;
        margin: 40px auto;
        background: rgba(0, 0, 0, 0.85);
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 25px rgba(255, 136, 0, 0.5);
        animation: fadeIn 1s ease;
    }
    .container h2 {
        font-family: 'Pacifico', cursive;
        font-size: 32px;
        color: #ff8800;
        text-align: center;
        margin-bottom: 25px;
    }
    form {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }
    label {
        font-weight: 500;
        color: #ddd;
    }
    input, select, textarea {
        padding: 10px;
        border: none;
        border-radius: 6px;
        outline: none;
        background: #f4f4f4;
        color: #333;
        font-size: 15px;
    }
    textarea {
        resize: vertical;
    }
    .submit-btn {
        background: linear-gradient(135deg, #ff8800, #ff6600);
        color: #fff;
        padding: 12px 25px;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        box-shadow: 0 0 15px rgba(255, 136, 0, 0.6);
        transition: transform 0.3s, background 0.3s;
    }
    .submit-btn:hover {
        transform: scale(1.05);
        background: linear-gradient(135deg, #ff6600, #cc5200);
    }
    footer {
        background: rgba(0, 0, 0, 0.8);
        padding: 15px;
        color: #fff;
        text-align: center;
        margin-top: auto;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
</head>
<body>

<header>
    <a href="hiring.php" class="back-btn">⬅ Back</a>
    Application Form 🇵🇭
</header>

<div class="container">
    <h2>Be Part of Job & Grab!</h2>
    
    <form action="process_application.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="contact">Contact Number:</label>
        <input type="text" name="contact" id="contact" required>

        <label for="email">Email Address:</label>
        <input type="email" name="email" id="email" required>

        <label for="position">Position Applying For:</label>
        <select name="position" id="position" required>
            <option value="">-- Select --</option>
            <option value="Crew">Crew</option>
            <option value="Riders">Riders</option>
            <option value="Service staf">Service staf</option>
        </select>

        <label for="message">Why do you want to join us?</label>
        <textarea name="message" id="message" rows="4" required></textarea>

        <button class="submit-btn" type="submit">Submit Application</button>
    </form>
</div>

<footer>
    &copy; 2025 Job & Grab. All rights reserved.
</footer>

</body>
</html>
