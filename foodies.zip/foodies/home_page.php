<?php
session_start();
include('config.php');

// Fetch all items from the database
$sql = "SELECT * FROM items";
$result = $conn->query($sql);

// Check if there are any items
if ($result->num_rows > 0) {
    $items = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $items = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Online Food Ordering</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .item {
            border: 1px solid #ccc;
            padding: 20px;
            width: 200px;
            text-align: center;
        }
        .item img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .item h3 {
            font-size: 18px;
        }
        .item p {
            font-size: 14px;
            color: #555;
        }
        .item button {
            padding: 10px;
            background-color: #28a745;
            color: white;
            border: none;
            cursor: pointer;
        }
        .item button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>

    <header>
        <h1>Welcome to Online Food Ordering</h1>
        <nav>
            <a href="cart.php">View Cart</a> | 
            <a href="login.php">Login</a> |
            <a href="logout.php">Logout</a>
        </nav>
    </header>

    <div class="container">
        <?php if (!empty($items)): ?>
            <?php foreach ($items as $item): ?>
                <div class="item">
                    <img src="images/<?= $item['image'] ?>" alt="<?= $item['name'] ?>"> <!-- Assuming you have images for each item -->
                    <h3><?= $item['name'] ?></h3>
                    <p>Price: $<?= number_format($item['price'], 2) ?></p>
                    <a href="product_details.php?id=<?= $item['id'] ?>">
                        <button>View Details</button>
                    </a>
                    <form action="add_to_cart.php" method="POST">
                        <input type="hidden" name="item_id" value="<?= $item['id'] ?>">
                        <input type="number" name="quantity" value="1" min="1" required>
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>No items available at the moment. Please check back later.</p>
        <?php endif; ?>
    </div>

</body>
</html>
