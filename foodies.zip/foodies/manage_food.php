<?php
require_once 'config.php'; // Database connection

// ADD FOOD
if (isset($_POST['add_food'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];

    $image = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image);
    }

    $query = "INSERT INTO menu (name, price, category, image) VALUES ('$name', '$price', '$category', '$image')";
    mysqli_query($conn, $query);
    header("Location: manage_food.php");
    exit();
}

// DELETE FOOD
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM menu WHERE id='$id'");
    header("Location: manage_food.php");
    exit();
}

// FETCH FOR EDIT
$edit_mode = false;
$edit_id = "";
$edit_name = "";
$edit_price = "";
$edit_category = "";
$edit_image = "";

if (isset($_GET['edit'])) {
    $edit_mode = true;
    $edit_id = $_GET['edit'];
    $edit_query = mysqli_query($conn, "SELECT * FROM menu WHERE id='$edit_id'");
    if ($edit_row = mysqli_fetch_assoc($edit_query)) {
        $edit_name = $edit_row['name'];
        $edit_price = $edit_row['price'];
        $edit_category = $edit_row['category'];
        $edit_image = $edit_row['image'];
    }
}

// UPDATE FOOD
if (isset($_POST['update_food'])) {
    $id = $_POST['food_id'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $image = $_POST['old_image'];

    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = 'uploads/' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $image);
    }

    mysqli_query($conn, "UPDATE menu SET name='$name', price='$price', category='$category', image='$image' WHERE id='$id'");
    header("Location: manage_food.php");
    exit();
}

// FETCH ALL
$foods = mysqli_query($conn, "SELECT * FROM menu");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Food Items</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background-color: #0f0f0f; color: #fff; }
        .navbar { background-color: #111; }
        .navbar-brand { font-weight: bold; color: #ffa31a !important; }
        .container { margin-top: 40px; background-color: #1a1a1a; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(255, 163, 26, 0.5); }
        .form-control { background-color: #333; border: 1px solid #ffa31a; color: #fff; }
        .form-control::placeholder { color: #ccc; }
        .btn-orange { background-color: #ffa31a; color: #0f0f0f; font-weight: bold; border: none; }
        .btn-orange:hover { background-color: #ff8c00; color: #fff; }
        .btn-danger { background-color: #ff4d4d; border: none; }
        .btn-danger:hover { background-color: #cc0000; }
        .btn-back { background-color: #333; border: 1px solid #ffa31a; color: #ffa31a; }
        .btn-back:hover { background-color: #ffa31a; color: #000; }
        th { background-color: #222; color: #ffa31a; }
        tr:hover { background-color: #292929; }
        img.food-img { width: 60px; height: 60px; object-fit: cover; border-radius: 5px; }
    </style>
</head>
<body>

<nav class="navbar navbar-dark">
    <div class="container-fluid d-flex justify-content-between">
        <a class="navbar-brand" href="#">Manage Food Items</a>
    </div>
</nav>

<div class="container">
    <h2 class="text-center mb-4"><?= $edit_mode ? '✏️ Edit Food Item' : '🍔 Add New Food Item' ?></h2>

    <!-- Add / Edit Food Form -->
    <form method="POST" enctype="multipart/form-data" class="mb-4">
        <input type="hidden" name="food_id" value="<?= $edit_id ?>">
        <input type="hidden" name="old_image" value="<?= $edit_image ?>">
        <div class="mb-3">
            <input type="text" name="name" class="form-control" placeholder="Food Name" value="<?= $edit_name ?>" required>
        </div>
        <div class="mb-3">
            <input type="number" step="0.01" name="price" class="form-control" placeholder="Price" value="<?= $edit_price ?>" required>
        </div>
        <div class="mb-3">
            <select name="category" class="form-control" required>
                <option value="">-- Select Category --</option>
                <option value="Appetizer" <?= $edit_category == 'Appetizer' ? 'selected' : '' ?>>Appetizer</option>
                <option value="Main Course" <?= $edit_category == 'Main Course' ? 'selected' : '' ?>>Main Course</option>
                <option value="Dessert" <?= $edit_category == 'Dessert' ? 'selected' : '' ?>>Dessert</option>
                <option value="Drink" <?= $edit_category == 'Drink' ? 'selected' : '' ?>>Drink</option>
            </select>
        </div>
        <div class="mb-3">
            <input type="file" name="image" class="form-control">
            <?php if ($edit_image): ?>
                <div class="mt-2">
                    <img src="<?= $edit_image ?>" alt="Current Image" class="food-img">
                </div>
            <?php endif; ?>
        </div>
        <button type="submit" name="<?= $edit_mode ? 'update_food' : 'add_food' ?>" class="btn btn-orange w-100">
            <?= $edit_mode ? '💾 Update Food' : '➕ Add Food' ?>
        </button>
    </form>

    <!-- Food Table -->
    <table class="table table-dark table-hover text-center">
        <thead>
            <tr><th>ID</th><th>Image</th><th>Name</th><th>Price</th><th>Category</th><th>Actions</th></tr>
        </thead>
        <tbody>
            <?php while ($food = mysqli_fetch_assoc($foods)): ?>
                <tr>
                    <td><?= $food['id'] ?></td>
                    <td>
                        <?php if ($food['image']): ?>
                            <img src="<?= $food['image'] ?>" class="food-img" alt="Image">
                        <?php else: ?>
                            <span>No Image</span>
                        <?php endif; ?>
                    </td>
                    <td><?= htmlspecialchars($food['name']) ?></td>
                    <td>₱<?= number_format($food['price'], 2) ?></td>
                    <td><?= htmlspecialchars($food['category']) ?></td>
                    <td>
                        <a href="manage_food.php?edit=<?= $food['id'] ?>" class="btn btn-orange btn-sm">✏️ Edit</a>
                        <a href="manage_food.php?delete=<?= $food['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this food item?')">❌ Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <a href="admin.php" class="btn btn-back w-100 mt-3">⬅️ Back to Admin</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
