<?php
require_once 'config.php';

// Optional: Insert notification function (if you have a notifications table)
function logNotification($conn, $message) {
    $stmt = $conn->prepare("INSERT INTO notifications (message, created_at) VALUES (?, NOW())");
    $stmt->bind_param("s", $message);
    $stmt->execute();
    $stmt->close();
}

// Confirm order logic
if (isset($_GET['confirm'])) {
    $order_id = intval($_GET['confirm']); // security
    $order_info = mysqli_query($conn, "SELECT full_name FROM orders WHERE id = $order_id LIMIT 1");

    if ($order_info && mysqli_num_rows($order_info) > 0) {
        $order = mysqli_fetch_assoc($order_info);
        $update = mysqli_query($conn, "UPDATE orders SET status = 'Confirmed' WHERE id = $order_id");

        // Add notification (optional)
        logNotification($conn, "Order #$order_id by {$order['full_name']} confirmed.");

        header("Location: confirm_orders.php");
        exit();
    }
}

// Fetch pending orders
$pending_orders = mysqli_query($conn, "SELECT * FROM orders WHERE status = 'Pending' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirm Orders</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #0f0f0f;
            color: #ffffff;
            font-family: Arial, sans-serif;
        }
        .container {
            margin-top: 40px;
        }
        .table {
            background-color: #1a1a1a;
            color: #ffffff;
        }
        .table thead {
            background-color: #222;
            color: #ffa31a;
        }
        .btn-orange {
            background-color: #ffa31a;
            color: #0f0f0f;
            font-weight: bold;
        }
        .btn-orange:hover {
            background-color: #ff8c00;
            color: #fff;
        }
        .btn-back {
            background-color: #333;
            color: #ffa31a;
            border: 1px solid #ffa31a;
        }
        .btn-back:hover {
            background-color: #ffa31a;
            color: #000;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📦 Confirm Pending Orders</h2>

    <?php if (mysqli_num_rows($pending_orders) > 0): ?>
    <table class="table table-bordered table-hover text-center">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Status</th>
                <th>Date Ordered</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($order = mysqli_fetch_assoc($pending_orders)): ?>
                <tr>
                    <td><?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['full_name']) ?></td>
                    <td><?= htmlspecialchars($order['item']) ?></td>
                    <td><?= $order['qty'] ?></td>
                    <td>₱<?= number_format($order['price'], 2) ?></td>
                    <td><?= $order['status'] ?></td>
                    <td><?= $order['created_at'] ?></td>
                    <td>
                        <a href="?confirm=<?= $order['id'] ?>" class="btn btn-orange btn-sm" onclick="return confirm('Confirm this order?')">✅ Confirm</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p class="text-center">✅ No pending orders to confirm.</p>
    <?php endif; ?>

    <div class="text-center mt-4">
        <a href="admin.php" class="btn btn-back">⬅️ Back to Dashboard</a>
    </div>
</div>

</body>
</html>
