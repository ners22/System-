<?php
session_start();
$conn = new mysqli("localhost", "root", "", "system_food");

// Connection check
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Fetch applicants data
$sql = "SELECT id, name, position_applied, contact, resume FROM applicants ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Applicants List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: url('imahe/mama.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #ff9900;
            margin-bottom: 30px;
        }
        table {
            width: 90%;
            margin: auto;
            border-collapse: collapse;
            background: rgba(0,0,0,0.8);
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #555;
        }
        th {
            background: #ff9900;
            color: black;
        }
        tr:hover {
            background: rgba(255, 153, 0, 0.2);
        }
        .btn {
            background: #ff9900;
            color: black;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            text-decoration: none;
        }
        .btn:hover {
            background: #cc7a00;
        }
        .nav {
            text-align: center;
            margin-bottom: 20px;
        }
        .nav a {
            background: #ff9900;
            color: black;
            padding: 10px 15px;
            margin: 5px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .nav a:hover {
            background: #cc7a00;
        }
    </style>
</head>
<body>

<div class="nav">
    <a href="index.php">🏠 Home</a>
    <a href="hiring.php">➕ New Application</a>
</div>

<h1>Online Job Applicants</h1>

<?php if ($result && $result->num_rows > 0): ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Email</th>
            <th>Position</th>
            <th>Resume File</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['position']); ?></td>
                <td>
                    <?php if (!empty($row['resume'])): ?>
                        <a class="btn" href="uploads/<?php echo urlencode($row['resume']); ?>" target="_blank">View</a>
                    <?php else: ?>
                        N/A
                    <?php endif; ?>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p style="text-align:center; font-size:18px;">No applicants yet.</p>
<?php endif; ?>

</body>
</html>
